"""
Author: Ronald de Jong
Student number: 1328328
Last updated: 20/05/2021
"""

### Import libraries and configure settings ###
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '1'

import numpy as np
import glob
import tensorflow as tf

from utils import read_nifti_file, create_patches

# Configure tensorflow
config = tf.compat.v1.ConfigProto()
config.gpu_options.allow_growth = True
session = tf.compat.v1.Session(config=config)


### To be defined by user ###
data_path = '/media/beta/yasmina+aymen-beps/ronald/data'
#data_path = 'D:/data'
train_path = '/media/beta/yasmina+aymen-beps/ronald/data_patches/16x16x16v2/train/'
val_path = '/media/beta/yasmina+aymen-beps/ronald/data_patches/16x16x16v2/val/'
test_path = '/media/beta/yasmina+aymen-beps/ronald/data_patches/16x16x16v2/test/'

image_size = (256, 320, 256)
patch_shape =(16, 16, 16)
total_images = 100

train_size = 60
val_size = 20
test_size = 20


### Load data ###
print('Getting filenames...')

# Get real and synthetic paths names
path_real = os.path.join(data_path, 'Real/T1/*')
path_axial = os.path.join(data_path, 'Synthesized/Axial/T1/*')
path_coronal = os.path.join(data_path, 'Synthesized/Coronal/T1/*')
path_sagittal = os.path.join(data_path, 'Synthesized/Sagittal/T1/*')
path_labels = os.path.join(data_path, 'labels/*')

# Get lists of real and synthetic image names
real_image_names = glob.glob(path_real)
axial_image_names = glob.glob(path_axial)
coronal_image_names = glob.glob(path_coronal)
sagittal_image_names = glob.glob(path_sagittal)
label_names = glob.glob(path_labels)

# Sort the images
real_image_names.sort()
axial_image_names.sort()
coronal_image_names.sort()
sagittal_image_names.sort()
label_names.sort()

### Store patches ###
print('Storing patches...')
    
k=0
l=0
m=0
for i in range(total_images):
    
    # Read and normalize the nifti file
    x_axial = read_nifti_file(axial_image_names[i])
    x_coronal = read_nifti_file(coronal_image_names[i])
    x_sagittal = read_nifti_file(sagittal_image_names[i])
    y = read_nifti_file(real_image_names[i])
    label = read_nifti_file(label_names[i])
    label = np.reshape(label, (256,320,256,1))
    y = np.reshape(y, (256,320,256,1))
    
    # Apply background label to synthesized images
    label[label > 0] = 1
    x_axial = np.multiply(x_axial, label)
    x_coronal = np.multiply(x_coronal, label)
    x_sagittal = np.multiply(x_sagittal, label)
    y = np.multiply(y, label)

    # Create patches
    x_axial_patches = create_patches(image=x_axial, patch_shape=patch_shape, ovl_perc=(0.5,0.5,0.5))
    x_coronal_patches = create_patches(image=x_coronal, patch_shape=patch_shape, ovl_perc=(0.5,0.5,0.5))
    x_sagittal_patches = create_patches(image=x_sagittal, patch_shape=patch_shape, ovl_perc=(0.5,0.5,0.5))
    x_patches = np.concatenate((x_axial_patches, x_coronal_patches, x_sagittal_patches),-1)
    y_patches = create_patches(image=y, patch_shape=patch_shape, ovl_perc=(0.5,0.5,0.5))
    
    # Loop over patches of one 3D image
    for j in range(x_patches.shape[0]):
        
        # Get x patch and y patch
        x_patch = x_patches[j]
        y_patch = y_patches[j]
        
        # Get rid of black patches in test and validation set
        if i < train_size:
            if np.sum(x_patch) > 0:
                # Define filename and filepaths
                filename = str(k)
                x_filepath = train_path + 'x/' + filename
                y_filepath = train_path + 'y/' + filename
                
                # Save single patch
                np.save(x_filepath, x_patch)
                np.save(y_filepath, y_patch)
                        
                # Change filename of next patch
                k+=1
        elif i < train_size+val_size:
            if np.sum(x_patch) > 0:
        
                # Define filename and filepaths
                filename = str(l)
                x_filepath = val_path + 'x/' + filename
                y_filepath = val_path + 'y/' + filename
                
                # Save single patch
                np.save(x_filepath, x_patch)
                np.save(y_filepath, y_patch)
                        
                # Change filename of next patch
                l+=1
        else:
            # Define filename and filepaths
            filename = str(m)
            x_filepath = test_path + 'x/' + filename
            y_filepath = test_path + 'y/' + filename
            
            # Save single patch
            np.save(x_filepath, x_patch)
            np.save(y_filepath, y_patch)
                    
            # Change filename of next patch
            m+=1
            
    # Print progress
    print('processed', i+1, 'out of', total_images, 'images', end = "\r")