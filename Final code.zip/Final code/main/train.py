"""
Author: Ronald de Jong
Student number: 1328328
Last updated: 18/05/2021
"""

### Import libraries and configure settings ###
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '1'

import numpy as np
import glob
from matplotlib import pylab as plt
import time
import tensorflow as tf
import statistics
from tensorflow import keras
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import ModelCheckpoint, TensorBoard, EarlyStopping
from skimage.metrics import structural_similarity as ssim
from skimage.metrics import mean_squared_error as mse
from skimage.metrics import peak_signal_noise_ratio as psnr

from utils import read_nifti_file, store_nifti_file, load_patches, reconstruct_image, batch_generator, get_model

# Configure tensorflow
config = tf.compat.v1.ConfigProto()
config.gpu_options.allow_growth = True
session = tf.compat.v1.Session(config=config)


### To be defined by user ###
#data_path = '/media/beta/yasmina+aymen-beps/ronald/data_patches/32x32x32/'

predict_path = '/media/beta/yasmina+aymen-beps/ronald/predicted_images/'
train_path = '/media/beta/yasmina+aymen-beps/ronald/data_patches/32x32x32v6/train/'
val_path = '/media/beta/yasmina+aymen-beps/ronald/data_patches/32x32x32v6/val/'
x_test_path = '/media/beta/yasmina+aymen-beps/ronald/data_patches/32x32x32v6/test/x/'
y_test_path = '/media/beta/yasmina+aymen-beps/ronald/data'

train_size = 60   # Fill in integer, total data is 100 images
val_size = 20     # Fill in integer, total data is 100 images
test_size = 20     # Fill in integer, total data is 100 images

train_run_size = 60
val_run_size = 20
test_run_size = 20


patch_shape=(32,32,32)
image_size = (256, 320, 256)
ovl_perc = (0.5, 0.5, 0.5)
batch_size = 100
nr_epochs = 100

### Start time of program ###
start_time = time.time()

### Create data generators ###
print('Creating data generators...')

# Define path of input images (x) and real images (y) of training set
x_train_path = train_path + 'x'
y_train_path = train_path + 'y'
x_val_path = val_path + 'x'
y_val_path = val_path + 'y'

# Get nuber of files in x and y folder
train_count = len(glob.glob1(x_train_path ,"*.npy"))
val_count = len(glob.glob1(x_val_path ,"*.npy"))

# Change training and validation size
train_count = int(train_count*(train_run_size/train_size))
val_count = int(val_count*(val_run_size/val_size))

# Define train and validation IDs
train_ids = range(0, train_count)
val_ids = range(0, val_count)

# Get the train generator
train_generator = batch_generator(ids=train_ids, x_path=x_train_path , y_path=y_train_path, batch_size=batch_size)
val_generator = batch_generator(ids=val_ids, x_path=x_val_path , y_path=y_val_path, batch_size=batch_size)


### Create model ###
print('Creating model...')

# Get the model
input_shape = patch_shape + (3,)
model = get_model(input_shape=input_shape)

# Compile the model
model.compile(loss=keras.losses.mean_squared_error,
              optimizer=Adam(lr=0.01),
              metrics=['mse'])      #keras.losses.mean_squared_error, 

# Define model name, weights name and filepath
model_name = 'Model'
model_filepath = model_name + '.json'
weights_filepath = model_name + '_weights.hdf5'

# Serialize model to JSON
model_json = model.to_json() 
with open(model_filepath, 'w') as json_file:
    json_file.write(model_json)

# Define the model checkpoint and Tensorboard callbacks
checkpoint = ModelCheckpoint(weights_filepath, monitor='val_loss', verbose=1, save_best_only=True, mode='min')
tensorboard = TensorBoard(os.path.join('logs', model_name))
early_stop = EarlyStopping(monitor='val_loss', patience=4)
callbacks_list = [checkpoint, tensorboard, early_stop]

### Train model ###
print('Training model...')

history = model.fit(train_generator,
                    steps_per_epoch= train_count // (batch_size*2),
                    batch_size=batch_size, 
                    epochs=nr_epochs, 
                    callbacks=callbacks_list,
                    validation_data=val_generator,
                    validation_steps=val_count // (batch_size),
                    validation_batch_size=batch_size)

# Save history
np.save('my_history.npy',history.history)

### Make loss curves ###
print('Making loss curves...')

# Make training and validation loss plot
plt.plot(history.history['loss'], color='k', linestyle = '--')
plt.plot(history.history['val_loss'], color='grey')

# Add layout to plot
plt.title('Training and validation loss during training')
plt.ylabel('Loss')
plt.xlabel('Epoch')
plt.legend(['Training loss', 'Validation loss'], loc='upper right')
plt.grid(color='grey', linestyle='--', linewidth=0.4)
#plt.ylim([0,2])

# Save and show figure
plt.savefig('Loss curves.png', dpi=900)
plt.show()


### Testing model ###
print('testing model...')

# Get y 3D image names
path_real = os.path.join(y_test_path, 'Real/T1/*')
real_image_names = glob.glob(path_real)
real_image_names.sort()
y_test_names = real_image_names[train_size+val_size:train_size+val_size+test_size]

# Compute patches in test size and patches per image
test_count = len(glob.glob1(x_test_path ,"*.npy"))
patches_per_img = test_count//test_size
print('patches per img:', patches_per_img)

# Get first and last patch for the first image
j_start = 0
j_end = patches_per_img

# Create lists for metrics per image
mse_list = []
ssim_list = []
psnr_list = []

# Loop over patches in test set
for i in range(test_run_size):
    # Get y data
    y_test = read_nifti_file(y_test_names[i])
    #print(y_test_names[i])
    
    # Get list of patch filenames for a single x image
    x_filenames = [x_test_path+str(x)+'.npy' for x in range(j_start, j_end)]
    
    # Get x patches
    x_patches = load_patches(filenames=x_filenames)
    
    # Test model
    y_pred_patches = model.predict(x_patches)
    
    # Reconstruct patches into 3D
    y_pred = reconstruct_image(y_pred_patches, patch_shape=patch_shape)

    # Save predicted 3D image as nifti file
    img_name = real_image_names[i].rpartition('/')[-1]    
    store_nifti_file(y_pred, predict_path + "pred_img_" + img_name)
    
    # Update the first and last patch for the next image
    j_start += patches_per_img
    j_end += patches_per_img
    
    # Compute relevant metrics
    MSE = mse(y_test, y_pred)
    SSIM = ssim(y_test, y_pred, data_range=1)
    PSNR = psnr(y_test, y_pred, data_range=1)
    
    # Add metrics of one image to array
    mse_list.append(MSE); ssim_list.append(SSIM); psnr_list.append(PSNR)
    
    # Print status
    print("Processed", i+1, "image(s)", end = "\r")

# Calculate mean and standard deviation for all metrics
mse_mean, mse_std = statistics.mean(mse_list), statistics.stdev(mse_list)
ssim_mean, ssim_std = statistics.mean(ssim_list), statistics.stdev(ssim_list)
psnr_mean, psnr_std = statistics.mean(psnr_list), statistics.stdev(psnr_list)

# Print statistic values
print('MSE:', "{:.4f}".format(mse_mean), u"\u00B1", "{:.4f}".format(mse_std))
print('SSIM:', "{:.4f}".format(ssim_mean), u"\u00B1", "{:.4f}".format(ssim_std))
print('PSNR:', "{:.2f}".format(psnr_mean), u"\u00B1", "{:.2f}".format(psnr_std))


### End of Program ###
run_time = time.time() - start_time
print('Program executed succesfully in:', run_time//60, 'minutes')