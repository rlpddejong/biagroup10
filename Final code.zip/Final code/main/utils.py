import numpy as np
import nibabel as nib
from scipy import ndimage
from matplotlib import pylab as plt
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras.layers import Conv3D, Dense, Dropout


def read_nifti_file(filepath):
    """ Reads a nifti file from given filepath
        Args:
                  filepath (str): The path + name of the image
        Returns:      
                  scan (numpy array): A 3D array containing a 3D image
    """
    # Read file
    scan = nib.load(filepath)
    # Get raw data
    scan = scan.get_fdata()
    # Get the 99.5 percentile
    perc = np.percentile(scan, 99.5)
    # Normalize image
    scan *= 1/perc
    return scan


def store_nifti_file(image, filepath):
    """Stores numpy array to nifti file
        Args:
                  image (numpy array): A 3D array containing a 3D image
                  filepath (str): The path + name of the image
        Returns:
                  None     
    """
    # Save axis for data (just identity)
    img = nib.Nifti1Image(image, np.eye(4))  
    img.header.get_xyzt_units()
    # Save as nifti file
    img.to_filename(filepath) 
    return


def create_patches(image, patch_shape=(8,8,8), ovl_perc=(0.5,0.5,0.5)):
    """Creates 3D patches from a 3D image
        Args:
                  image (numpy array): A 3D array containing a 3D image
                  patch_shape (tuple): A 3D tuple containing the size of the 
                                       patches in the sagittal, coronal, and
                                       axial direction respectively
        Returns:
                  patches (numpy array): Array containing patches of one image
    """
    # Define patch size
    x,y,z = patch_shape

    # Image conversion
    image = tf.convert_to_tensor(image, dtype=tf.float32)
    image = tf.reshape(image, (1,256,320,256,1))
    
    # Define size of 3D patches and strides
    ksizes = [1, x, y, z, 1]
    strides = [1, int(ovl_perc[0]*x), int(ovl_perc[1]*y), int(ovl_perc[2]*z), 1]
    
    # Make patches
    patches = tf.extract_volume_patches(image, ksizes, strides, 'VALID')
    
    # Convert to numpy
    patches = patches.numpy()  
    
    # Reshape patches such that the format is: (number_of_patches, voxels_in_patch)
    number_of_patches = patches.shape[1]*patches.shape[2]*patches.shape[3]
    patches = np.reshape(patches, (number_of_patches, patch_shape[0], patch_shape[1], patch_shape[2], 1))

    return patches


def load_patches(filenames):
    
    # Create list for patches of a single image
    patches = []
    
    # Loop over patch names of a single image
    for fname in filenames:
        # Load a single patch
        patch = np.load(fname)
        # Add patch to list of all patches per image
        patches.append(patch)
        
    # Change list type to numpy array
    patches = np.array(patches)
    
    return patches


def reconstruct_image(patches, patch_shape=(8,8,8), image_shape=(256,320,256), ovl_perc=(0.5,0.5,0.5)):
    """Reconstructs 3D image patches back to 3D volume
        Args:
                  patches (numpy array): Array containing patches one 3D image
                  patch_shape (tuple): A 3D tuple containing the size of the 
                                       patches in the sagittal, coronal, and
                                       axial direction respectively
                  image_shape (tuple): A 3D tuple containing the size of the 
                                       image in the sagittal, coronal, and
                                       axial direction respectively                    
        Returns:  
                  reconstructed (numpy array): A 3D array containing the 3D
                                               reconstructed image
    """
    # Get number of patches in every direction and get voxels in patch
    number_of_patches = patches.shape[0]
    x = patches.shape[1]
    y = patches.shape[2]
    z = patches.shape[3]
    voxels_in_patch = x*y*z
    
    nr_patches_x = int(image_shape[0]//x//ovl_perc[0]-1)
    nr_patches_y = int(image_shape[1]//y//ovl_perc[1]-1)
    nr_patches_z = int(image_shape[2]//z//ovl_perc[2]-1)
    
    # Redefine patch array shape
    patches = np.reshape(patches, (number_of_patches, voxels_in_patch))
    patches = np.reshape(patches, (1, nr_patches_x, nr_patches_y, nr_patches_z, voxels_in_patch))
    
    # Create reconstructed image array
    reconstructed= np.zeros(image_shape)
    
    # Redefine patch size because of overlap
    new_patch_size_x = int(ovl_perc[0]*x)
    new_patch_size_y = int(ovl_perc[1]*y)
    new_patch_size_z = int(ovl_perc[2]*z)
    
    # Define start point for the patch 
    start_x = int(new_patch_size_x//2)
    start_y = int(new_patch_size_y//2)
    start_z = int(new_patch_size_z//2)
    
    # Define end point for the patch 
    end_x = int(x-new_patch_size_x//2)
    end_y = int(x-new_patch_size_y//2)
    end_z = int(x-new_patch_size_z//2)
    
    # Define new coordinates of the patches
    x_new = int(x*ovl_perc[0])
    y_new = int(x*ovl_perc[1])
    z_new = int(x*ovl_perc[2])
    
    # Loop over patches in all 3 directions
    for i in range(nr_patches_x):
        xstart = i*x_new + x_new//2
    
        if i == 0:
            #x_new = int(new_patch_size_x*2)
            #xstart = 0
            #start_x = 0
            #end_x = int(new_patch_size_x*2)
            
            x_new = int(new_patch_size_x*1.5)
            end_x = int(new_patch_size_x*2)
            
        if i == nr_patches_x-1:
            end_x = patch_shape[1]+1
            x_new = int(new_patch_size_x*1.5)
        #print(xstart, xstart+x_new, start_x, end_x)
        for j in range(nr_patches_y):
            ystart = j*y_new + y_new//2
            
            if j == 0:
                y_new = int(new_patch_size_y*1.5)
                #ystart = 0
                #start_y = 0
                end_y = int(new_patch_size_y*2)
            if j == nr_patches_y-1:
                end_y = patch_shape[1]+1
                y_new = int(new_patch_size_y*1.5)
            
            for k in range(nr_patches_z):
                zstart = k*z_new + z_new//2  
                
                if k == 0:
                    z_new = int(new_patch_size_z*2)
                    zstart = 0
                    start_z = 0
                    end_z = int(new_patch_size_z*2)
                if k == nr_patches_z-1:
                    end_z = patch_shape[1]+1
                    z_new = int(new_patch_size_z*1.5)
                        
                # Extract a single patch from patch array
                patch_1D = patches[0,i,j,k,:]
                # Reschape the patch to make it 3D instead of 1D
                patch_3D = patch_1D.reshape(x,y,z)
                patch_3D = patch_3D[start_x:end_x, start_y:end_y, start_z:end_z]
                # Add the single patch to the right location in the reconstructed image
                reconstructed[xstart:xstart+x_new, ystart:ystart+y_new, zstart:zstart+z_new] = patch_3D
                
                # Redefine varbs
                # Define start point for the patch 
                start_x = int(new_patch_size_x//2)
                start_y = int(new_patch_size_y//2)
                start_z = int(new_patch_size_z//2)
                
                # Define end point for the patch 
                end_x = int(x-new_patch_size_x//2)
                end_y = int(x-new_patch_size_y//2)
                end_z = int(x-new_patch_size_z//2)
                
                # Define new coordinates of the patches
                x_new = int(x*ovl_perc[0])
                y_new = int(x*ovl_perc[1])
                z_new = int(x*ovl_perc[2])
                
    return reconstructed


def load_data(ids, x_path, y_path):
    """Loads x and y data for neural network given the ID numbers of the images 
       and the path of the x and y folders
    Args:
              ids (range): A range of numbers containing which are the numbers
                           of the files that need to be loaded
              x_path (string): A string containing the path of the x folder in 
                               which input patches (numpy arrays) are located
              y_path (string): A string containing the path of the y folder in 
                               which output patches (numpy arrays) are located
    Returns:
              np.array(X) (numpy array): Array containing the patches from the
                                         x folder
              np.array(Y) (numpy array): Array containing the patches from the
                                         y folder                                        
    """
    # Make list to store numpy arrays later on
    X = []
    Y = []

    # Loop over the image IDs
    for i in ids:
        # Convert the file number to a string
        filename = str(i)
        
        # Define filepaths
        x_filepath = x_path + '/' + filename + '.npy'
        y_filepath = y_path + '/' + filename + '.npy'
        
        # Load x and y patches
        x = np.load(x_filepath)
        y = np.load(y_filepath)
        
        # Add patches to array
        X.append(x)
        Y.append(y)

    return np.array(X), np.array(Y)


def batch_generator(ids, x_path, y_path, batch_size = 10):
    """Loads x and y data for neural network given the ID numbers of the images 
       and the path of the x and y folders
    Args:
              ids (range): A range of numbers containing which are the numbers
                           of the files that need to be loaded
              x_path (string): A string containing the path of the x folder in 
                               which input patches (numpy arrays) are located
              y_path (string): A string containing the path of the y folder in 
                               which output patches (numpy arrays) are located
              batch_size (int): An integer containing the number of patches to
                                be loaded at once
    Yields:
              Generator: Generator containing the np.array(X) and np.array(Y)
                         which are returned by load_data                                   
    """
    # Make empty batch to store patches later on
    batch=[]
    while True:
            # If the ids need to be shuffled uncomment the line below
            #np.random.shuffle(ids) 
            
            # Loop over ids in batch size
            for i in ids:
                batch.append(i)
                if len(batch)==batch_size:
                    # Load and yield the data from the batch
                    yield load_data(batch, x_path, y_path)
                    # Make batch empty to start with the next batch
                    batch=[]
     
        
def get_model(input_shape=(8,8,8,3)):
    """Creates a CNN model"""
    
    inp1 = keras.layers.Input(shape=(input_shape))
    inp2 = Dense(1, activation='linear')(inp1)
    
    layer1 = Conv3D(60, kernel_size=(3,3,3), padding='same', activation='relu')(inp1) #, kernel_initializer='he_uniform'
    layer2 =Conv3D(60, kernel_size=(3,3,3), padding='same', activation='relu')(layer1)
    drop1 = Dropout(0.2)(layer2)
    
    layer3 = Conv3D(60, kernel_size=(3,3,3), padding='same', activation='relu')(drop1)
    layer4 =Conv3D(60, kernel_size=(3,3,3), padding='same', activation='relu')(layer3)
    drop2 = Dropout(0.2)(layer4)
    
    act = Dense(1, activation='linear')(drop2)
    xout = keras.layers.add([inp2, act])
    
    model = keras.models.Model(inp1, xout)
    model.summary()
    
    return model


def plot_real_pred_slices(real_image, pred_image, axial_image, coronal_image, sagittal_image, median_image, path_name, img_name, slice_loc = 128, dpi=600):

    # Get slices and rotate them
    slice_real_ax = ndimage.rotate(real_image[:,:,slice_loc], 90)
    slice_real_cor = ndimage.rotate(real_image[:,slice_loc,:], 90)
    slice_real_sag = ndimage.rotate(real_image[slice_loc,:,:], 90)
        
    slice_pred_ax = ndimage.rotate(pred_image[:,:,slice_loc], 90)
    slice_pred_cor = ndimage.rotate(pred_image[:,slice_loc,:], 90)
    slice_pred_sag = ndimage.rotate(pred_image[slice_loc,:,:], 90)
    
    slice_median_ax = ndimage.rotate(median_image[:,:,slice_loc], 90)
    slice_median_cor = ndimage.rotate(median_image[:,slice_loc,:], 90)
    slice_median_sag = ndimage.rotate(median_image[slice_loc,:,:], 90)    
    
    slice_axial_ax = ndimage.rotate(axial_image[:,:,slice_loc], 90)
    slice_axial_cor = ndimage.rotate(axial_image[:,slice_loc,:], 90)
    slice_axial_sag = ndimage.rotate(axial_image[slice_loc,:,:], 90)    

    slice_coronal_ax = ndimage.rotate(coronal_image[:,:,slice_loc], 90)
    slice_coronal_cor = ndimage.rotate(coronal_image[:,slice_loc,:], 90)
    slice_coronal_sag = ndimage.rotate(coronal_image[slice_loc,:,:], 90)    

    slice_sagittal_ax = ndimage.rotate(sagittal_image[:,:,slice_loc], 90)
    slice_sagittal_cor = ndimage.rotate(sagittal_image[:,slice_loc,:], 90)
    slice_sagittal_sag = ndimage.rotate(sagittal_image[slice_loc,:,:], 90)  

    # Plot input image slices
    plt.figure()
    fig, ax = plt.subplots(3,3, gridspec_kw={
                           'width_ratios': [200, 200, 275],
                           'height_ratios': [320, 320, 320],
                           'wspace': -0.212,
                           'hspace': 0.03}) 

    fig.set_figheight(30/6)
    fig.set_figwidth(33/6)
    
    for k in range(3):
        for j in range(3):
            ax[k,j].set_xticks([])
            ax[k,j].set_yticks([])

    ax[0,0].imshow(slice_axial_ax, cmap = 'gray')
    ax[1,0].imshow(slice_coronal_ax, cmap = 'gray')
    ax[2,0].imshow(slice_sagittal_ax, cmap = 'gray')
    
    ax[0,1].imshow(slice_axial_cor, cmap = 'gray')
    ax[1,1].imshow(slice_coronal_cor, cmap = 'gray')
    ax[2,1].imshow(slice_sagittal_cor, cmap = 'gray')
    
    ax[0,2].imshow(slice_axial_sag, cmap = 'gray')
    ax[1,2].imshow(slice_coronal_sag, cmap = 'gray')
    ax[2,2].imshow(slice_sagittal_sag, cmap = 'gray')
    
    ax[0,1].set_title("         Input images")
    ax[0,0].set_ylabel('Axial')
    ax[1,0].set_ylabel('Coronal')
    ax[2,0].set_ylabel('Sagittal')
    
    # Save the plot 
    plt.savefig(path_name + img_name + "_input" +'.png', transparent=True, dpi=dpi)
    plt.close('all')
    
    
    # Plot output image slices
    plt.figure()
    fig, ax = plt.subplots(3,3, gridspec_kw={
                           'width_ratios': [200, 200, 275],
                           'height_ratios': [320, 320, 320],
                           'wspace': -0.212,
                           'hspace': 0.03}) 

    fig.set_figheight(30/6)
    fig.set_figwidth(33/6)
    
    for k in range(3):
        for j in range(3):
            ax[k,j].set_xticks([])
            ax[k,j].set_yticks([])
    
    ax[0,0].imshow(slice_real_ax, cmap = 'gray')
    ax[1,0].imshow(slice_pred_ax, cmap = 'gray')
    ax[2,0].imshow(slice_median_ax, cmap = 'gray')
    
    ax[0,1].imshow(slice_real_cor, cmap = 'gray')
    ax[1,1].imshow(slice_pred_cor, cmap = 'gray')
    ax[2,1].imshow(slice_median_cor, cmap = 'gray')
    
    ax[0,2].imshow(slice_real_sag, cmap = 'gray')
    ax[1,2].imshow(slice_pred_sag, cmap = 'gray')
    ax[2,2].imshow(slice_median_sag, cmap = 'gray')
    
    ax[0,1].set_title("          Real and output images")   
    ax[0,0].set_ylabel('Real')
    ax[1,0].set_ylabel('Predicted')
    ax[2,0].set_ylabel('Median')

    plt.savefig(path_name + img_name + "_output" +'.png', transparent=True, dpi=dpi)
    plt.close('all')  
    
    return


def plot_intensity_line(real_image, pred_image, path_name, img_name, dpi=600):
    
    # Configure subplot settings
    fig, ax = plt.subplots(3, figsize=(4.5,3.5))
    fig.tight_layout()
    plt.subplots_adjust(hspace=0.6)
    fig.set_figheight(6)
    fig.set_figwidth(5)
    
    # Axial subplot
    ax[0].plot(real_image[256//2,320//2,:])
    ax[0].plot(pred_image[256//2,320//2,:])
    ax[0].legend(["Real", "Predicted"])
    ax[0].set_title("Perpendicular to axial plane")
    ax[0].set_xlim([0, 256])
    ax[0].set_ylim([0, 0.6])
    ax[0].set_xlabel("Voxel")
    ax[0].set_ylabel("Intensity")    
    
    # Coronal subplot
    ax[1].plot(real_image[256//2,:,256//2])
    ax[1].plot(pred_image[256//2,:,256//2])
    ax[1].legend(["Real", "Predicted"])
    ax[1].set_title("Perpendicular to coronal plane")
    ax[1].set_xlim([0, 320])
    ax[2].set_ylim([0, 1.2])
    ax[1].set_xlabel("Voxel")
    ax[1].set_ylabel("Intensity")    
    
    # Sagittal subplot
    ax[2].plot(real_image[:,320//2,256//2])
    ax[2].plot(pred_image[:,320//2,256//2])
    ax[2].legend(["Real", "Predicted"])
    ax[2].set_title("Perpendicular to sagittal plane")
    ax[2].set_xlim([0, 256])
    ax[2].set_ylim([0, 0.8])
    ax[2].set_xlabel("Voxel")
    ax[2].set_ylabel("Intensity") 
    
    # Save figure
    plt.savefig(path_name + img_name +'.png', transparent=True, dpi=dpi)
    plt.show()
    plt.close('all')

    return