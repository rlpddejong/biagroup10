"""
Author: Ronald de Jong
Student number: 1328328
Last updated: 18/05/2021
"""

### Import libraries and configure settings ###
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '1'

import sys
import numpy as np
import glob
import statistics
from skimage.metrics import structural_similarity as ssim
from skimage.metrics import mean_squared_error as mse
from skimage.metrics import peak_signal_noise_ratio as psnr

from utils import read_nifti_file, plot_real_pred_slices, plot_intensity_line

## User settings ##

# Specify folders of predicted images in list where every entry is a different run
path_pred = '/media/beta/yasmina+aymen-beps/ronald/predicted_images/4/'

path_real = '/media/beta/yasmina+aymen-beps/ronald/data/Real/T1/'
path_axial = '/media/beta/yasmina+aymen-beps/ronald/data/Synthesized/Axial/T1/'
path_coronal = '/media/beta/yasmina+aymen-beps/ronald/data/Synthesized/Coronal/T1/'
path_sagittal = '/media/beta/yasmina+aymen-beps/ronald/data/Synthesized/Sagittal/T1/'

image_shape=(256,320,256)
total_size = 100
test_size = 20


## Create directories and create empty lists to store results ##
print("Creating locations to store data...")

# Create folders if not existing yet
if not os.path.exists("evaluation"):
    os.mkdir("evaluation")
slice_plot_dir = "evaluation/slice_plots"
if not os.path.exists(slice_plot_dir):
    os.mkdir(slice_plot_dir)
intensity_plot_dir = "evaluation/intensity_plots"
if not os.path.exists(intensity_plot_dir):
    os.mkdir(intensity_plot_dir)
    
# Create lists for metrics per image
mse_list = [[], [], [], [], []]
ssim_list = [[], [], [], [], []]
psnr_list = [[], [], [], [], []]


## Get ordered list of image names ##
print("Getting image names...")

# Get list of real image names
real_image_glob = os.path.join(path_real, '*')
real_image_names = glob.glob(real_image_glob)
real_image_names.sort()
real_image_names = real_image_names[total_size-test_size:total_size]

# Get list of sagittal synthesized image names
axial_image_glob = os.path.join(path_axial, '*')
axial_image_names = glob.glob(axial_image_glob)
axial_image_names.sort()
axial_image_names = axial_image_names[total_size-test_size:total_size]

# Get list of coronal synthesized image names
coronal_image_glob = os.path.join(path_coronal, '*')
coronal_image_names = glob.glob(coronal_image_glob)
coronal_image_names.sort()
coronal_image_names = coronal_image_names[total_size-test_size:total_size]

# Get list of sagittal synthesized image names
sagittal_image_glob = os.path.join(path_sagittal, '*')
sagittal_image_names = glob.glob(sagittal_image_glob)
sagittal_image_names.sort()
sagittal_image_names = sagittal_image_names[total_size-test_size:total_size]

# Get list of predicted image names
pred_image_glob = os.path.join(path_pred, '*')
pred_image_names = glob.glob(pred_image_glob)
pred_image_names.sort()


## Evaluate statistics of input data ##
print("Evaluating statistic values and making plots per image...")

# Loop over the image names
for i in range(len(real_image_names)):
    
    # Read one real and it's corresponding predicted image and get name
    img_name = real_image_names[i].rpartition('/')[-1]
    
    # Read one real and it's corresponding predicted image
    real_image = read_nifti_file(real_image_names[i])
    axial_image = read_nifti_file(axial_image_names[i]).reshape(image_shape)
    coronal_image = read_nifti_file(coronal_image_names[i]).reshape(image_shape)
    sagittal_image = read_nifti_file(sagittal_image_names[i]).reshape(image_shape)
    median_image = np.median([axial_image, coronal_image, sagittal_image], axis=0) 
    pred_image = read_nifti_file(pred_image_names[i])
    
    # Compute relevant metrics
    for index, image_name in enumerate([axial_image, coronal_image, sagittal_image, median_image, pred_image]):
        # Compute satistic values
        MSE = mse(real_image, image_name)
        SSIM = ssim(real_image, image_name, data_range=1)
        PSNR = psnr(real_image, image_name , data_range=1)
        # Add metrics of one image to array
        mse_list[index].append(MSE); ssim_list[index].append(SSIM); psnr_list[index].append(PSNR)
    
    # Create sliced plots of real vs. predicted data
    plot_real_pred_slices(real_image, pred_image, axial_image, coronal_image, 
                          sagittal_image, median_image, path_name=slice_plot_dir, 
                          img_name="/slice_plot_" + img_name, dpi=600)
    
    # Plot intensity graphs along a line in the middle of the volume
    plot_intensity_line(real_image, pred_image, path_name=intensity_plot_dir, 
                        img_name="/intensity_plot_" + img_name, dpi=600)
    
    # Print status
    print(" -> Processed", i+1, "image(s) out of", len(real_image_names),"images", end = "\r") 


## Post process statistic values ##
print("Processing, printing, and storing statistic values...")

## Calculate mean and standard deviation of statistic values ##
for index, l in enumerate(mse_list):
    mse_list[index] = (statistics.mean(l), statistics.stdev(l))
for index, l in enumerate(ssim_list):
    ssim_list[index] = (statistics.mean(l), statistics.stdev(l))
for index, l in enumerate(psnr_list):
    psnr_list[index] = (statistics.mean(l), statistics.stdev(l))

# Print metric values
print('Axial MSE     :', "{:.4f}".format(mse_list[0][0]), u"\u00B1", "{:.4f}".format(mse_list[0][1]))
print('Coronal MSE   :', "{:.4f}".format(mse_list[1][0]), u"\u00B1", "{:.4f}".format(mse_list[1][1]))
print('Sagittal MSE  :', "{:.4f}".format(mse_list[2][0]), u"\u00B1", "{:.4f}".format(mse_list[2][1]))
print('Median MSE    :', "{:.4f}".format(mse_list[3][0]), u"\u00B1", "{:.4f}".format(mse_list[3][1]))
print('Predicted MSE :', "{:.4f}".format(mse_list[4][0]), u"\u00B1", "{:.4f}".format(mse_list[4][1]))
print('Axial SSIM    :', "{:.4f}".format(ssim_list[0][0]), u"\u00B1", "{:.4f}".format(ssim_list[0][1]))
print('Coronal SSIM  :', "{:.4f}".format(ssim_list[1][0]), u"\u00B1", "{:.4f}".format(ssim_list[1][1]))
print('Sagittal SSIM :', "{:.4f}".format(ssim_list[2][0]), u"\u00B1", "{:.4f}".format(ssim_list[2][1]))
print('Median SSIM   :', "{:.4f}".format(ssim_list[3][0]), u"\u00B1", "{:.4f}".format(ssim_list[3][1]))
print('Predicted SSIM:', "{:.4f}".format(ssim_list[4][0]), u"\u00B1", "{:.4f}".format(ssim_list[4][1]))
print('Axial PSNR    :', "{:.2f}".format(psnr_list[0][0]), u"\u00B1", "{:.2f}".format(psnr_list[0][1]))
print('Coronal PSNR  :', "{:.2f}".format(psnr_list[1][0]), u"\u00B1", "{:.2f}".format(psnr_list[1][1]))
print('Sagittal PSNR :', "{:.2f}".format(psnr_list[2][0]), u"\u00B1", "{:.2f}".format(psnr_list[2][1]))
print('Median PSNR   :', "{:.2f}".format(psnr_list[3][0]), u"\u00B1", "{:.2f}".format(psnr_list[3][1]))
print('Predicted PSNR:', "{:.2f}".format(psnr_list[4][0]), u"\u00B1", "{:.2f}".format(psnr_list[4][1]))

# Save raw metric data to .txt file
original_stdout = sys.stdout
with open('evaluation/metrics.txt', 'w') as f:
    sys.stdout = f # Change the standard output to the file we created.
    print("-----------\nMSE values \n-----------")
    print("Axial data    :", mse_list[0][0], u"\u00B1", mse_list[0][1])
    print("Coronal data  :", mse_list[1][0], u"\u00B1", mse_list[1][1])
    print("Sagittal data :", mse_list[2][0], u"\u00B1", mse_list[2][1])
    print("Median data   :", mse_list[3][0], u"\u00B1", mse_list[3][1])
    print("Predicted data:", mse_list[4][0], u"\u00B1", mse_list[4][1])
    print("\n-----------\nSSIM values \n-----------")   
    print("Axial data    :", ssim_list[0][0], u"\u00B1", ssim_list[0][1])
    print("Coronal data  :", ssim_list[1][0], u"\u00B1", ssim_list[1][1])
    print("Sagittal data :", ssim_list[2][0], u"\u00B1", ssim_list[2][1])
    print("Median data   :", ssim_list[3][0], u"\u00B1", ssim_list[3][1])    
    print("Predicted data:", ssim_list[4][0], u"\u00B1", ssim_list[4][1]) 
    print("\n-----------\nPSNR values \n-----------") 
    print("Axial data    :", psnr_list[0][0], u"\u00B1", psnr_list[0][1])
    print("Coronal data  :", psnr_list[1][0], u"\u00B1", psnr_list[1][1])
    print("Sagittal data :", psnr_list[2][0], u"\u00B1", psnr_list[2][1])
    print("Median data   :", psnr_list[3][0], u"\u00B1", psnr_list[3][1])      
    print("Predicted data:", psnr_list[4][0], u"\u00B1", psnr_list[4][1])    
    sys.stdout = original_stdout # Reset the standard output to its original value