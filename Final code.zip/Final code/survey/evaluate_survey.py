
## Import relevant libraries ##
import pandas as pd
import numpy as np
import scipy.stats
import matplotlib.pyplot as plt


## Functions ##
def get_occurrence(data, ids):
    # Make a dataframe from the excel file
    df = pd.DataFrame(data, columns=ids)
    
    # Convert to array
    arr = np.array(df)

    # Count occurances of 1 to 5
    occ_1 = np.count_nonzero(arr == 1)
    occ_2 = np.count_nonzero(arr == 2)
    occ_3 = np.count_nonzero(arr == 3)
    occ_4 = np.count_nonzero(arr == 4)
    occ_5 = np.count_nonzero(arr == 5)
    
    return [occ_1, occ_2, occ_3, occ_4, occ_5]

def get_data(data, ids):
    df = pd.DataFrame(data, columns=ids)    
    arr = np.array(df)
    arr = np.reshape(arr, arr.size)
    return arr

## User specifications ##
# Specify path of excel file containing results
data = pd.read_excel(r'D:/survey_results.xlsx') 

""" IDs including the first six images of the survey
# Specify array of IDs belonging to certain class
real_ids = ["2","3","6","7","9","11","12","15","19","20","22","24","25","26","28"]
pred_ids = ["1","4","5","8","10","13","14","16","17","18","21","23","27","29","30"]

real_axial_ids = ["2","7","15","22","25"]
real_coronal_ids = ["3","9","12","24","28"]
real_sagittal_ids = ["6","11","19","20","26"]
pred_axial_ids = ["4","16","17","21","27"]
pred_coronal_ids = ["5","8","18","23","29"]
pred_sagittal_ids = ["1","10","13","14","30"]
"""

# Image IDs exluding the first six images of the survey
real_ids = ["7","9","11","12","15","19","20","22","24","25","26","28"]
pred_ids = ["8","10","13","14","16","17","18","21","23","27","29","30"]

real_axial_ids = ["7","15","22","25"]
real_coronal_ids = ["9","12","24","28"]
real_sagittal_ids = ["11","19","20","26"]
pred_axial_ids = ["16","17","21","27"]
pred_coronal_ids = ["8","18","23","29"]
pred_sagittal_ids = ["10","13","14","30"]


## Plot 1: bar chart predicted vs. real ##
# Get occurences in list
occ_real = get_occurrence(data, real_ids)
occ_pred = get_occurrence(data, pred_ids)

# Make plot
w = 0.4
plt.bar([1-w/2, 2-w/2, 3-w/2, 4-w/2, 5-w/2], occ_real, width=w)
plt.bar([1+w/2, 2+w/2, 3+w/2, 4+w/2, 5+w/2], occ_pred, width=w)
plt.title("Occurrences per quality rating")
plt.xlabel("Quality rating")
plt.ylabel("Occurrence")
plt.legend(["Real", "Predicted"])
plt.ylim([0,max(max(occ_real),max(occ_pred))+20])
xlocs = [1-w/2, 2-w/2, 3-w/2, 4-w/2, 5-w/2]
for i, v in enumerate(occ_real):
    plt.text(xlocs[i]-0.14, v + 4, str(v))
xlocs = [1+w/2, 2+w/2, 3+w/2, 4+w/2, 5+w/2]
for i, v in enumerate(occ_pred):
    plt.text(xlocs[i]-0.14, v + 4, str(v))
plt.savefig("Bar chart real vs. predicted data.png", dpi=600)
plt.show() 


## Plot 2: bar chart per category ##
# Get data per category
real_data = get_data(data, real_ids)
pred_data = get_data(data, pred_ids)
real_axial_data = get_data(data, real_axial_ids)
real_coronal_data = get_data(data, real_coronal_ids) 
real_sagittal_data = get_data(data, real_sagittal_ids)
pred_axial_data = get_data(data, pred_axial_ids)
pred_coronal_data = get_data(data, pred_coronal_ids)
pred_sagittal_data = get_data(data, pred_sagittal_ids)

# Compute mean and std
mean_real = [np.mean(real_data), np.mean(real_axial_data), np.mean(real_coronal_data), np.mean(real_sagittal_data)]
mean_pred = [np.mean(pred_data), np.mean(pred_axial_data), np.mean(pred_coronal_data), np.mean(pred_sagittal_data)]
std_real = [np.std(real_data), np.std(real_axial_data), np.std(real_coronal_data), np.std(real_sagittal_data)]
std_pred = [np.std(pred_data), np.std(pred_axial_data), np.std(pred_coronal_data), np.std(pred_sagittal_data)]
        
# Plot bar chart predicted vs. real
w = 0.4
plt.bar([1-w/2, 2-w/2, 3-w/2, 4-w/2], mean_real, yerr=std_real, width=w, ecolor='black', error_kw=dict(lw=1, capsize=8, capthick=1))
plt.bar([1+w/2, 2+w/2, 3+w/2, 4+w/2], mean_pred, yerr=std_pred, width=w, ecolor='black',error_kw=dict(lw=1, capsize=8, capthick=1))
plt.xticks([1, 2, 3,4], ["Overall", "Axial", "Coronal", "Sagittal"])
plt.title("Average quality ratings per category")
plt.xlabel("Category")
plt.ylabel("Average quality rating")
plt.legend(["Real", "Predicted"])
plt.grid(axis="y", color="gray",alpha=0.6)
plt.savefig("Bar chart per category.png", dpi=600)
plt.show() 


k_stat_pred, p_val_pred = scipy.stats.kstest(pred_data, 'norm')
k_stat_real, p_val_real = scipy.stats.kstest(real_data, 'norm')

print(p_val_pred, p_val_real)
        
## Paired two-sided T-test ##
# Perform T-test
t_stat, p_val = scipy.stats.ttest_rel(pred_data, real_data)

# Print statistic values
print("T-test with null hypothesis: Two related or repeated samples have identical average (expected) values.")
print("t-statistic:", "{:.3f}".format(t_stat))
print("P-value:", "{:.3e}".format(p_val))

# Test and print wheter or not the null hypothesis can be rejected
alpha = 0.05
if p_val < alpha:
    print("Null hypothesis rejected: Two related samples have different average (expected) values.")
else:
    print("Null hypothesis is true: Two related samples have identical average (expected) values.")
