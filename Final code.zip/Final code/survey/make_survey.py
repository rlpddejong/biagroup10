import nibabel as nib
from matplotlib import pylab as plt
import numpy as np
from scipy import ndimage

def read_nifti_file(filepath):
    """ Reads a nifti file from given filepath
        Args:
                  filepath (str): The path + name of the image
        Returns:      
                  scan (numpy array): A 3D array containing a 3D image
    """
    # Read file
    scan = nib.load(filepath)
    # Get raw data
    scan = scan.get_fdata()
    # Get the 99.5 percentile
    perc = np.percentile(scan, 99.5)
    # Normalize image
    scan *= 1/perc
    return scan



# Store path
store_path = 'D:/survey'

# Specify path and filename
filenames_list = [('D:/data/Real/T1/135124_3T_T1w_MPR1_img.nii.gz', 'D:/BEST model 2 run 1/predicted_image_nr_1.nii.gz'),
                 ('D:/data/Real/T1/135225_3T_T1w_MPR1_img.nii.gz', 'D:/BEST model 2 run 1/predicted_image_nr_2.nii.gz'),
                 ('D:/data/Real/T1/135528_3T_T1w_MPR1_img.nii.gz', 'D:/BEST model 2 run 1/predicted_image_nr_3.nii.gz'),
                 ('D:/data/Real/T1/135629_3T_T1w_MPR1_img.nii.gz', 'D:/BEST model 2 run 1/predicted_image_nr_4.nii.gz'),
                 ('D:/data/Real/T1/135730_3T_T1w_MPR1_img.nii.gz', 'D:/BEST model 2 run 1/predicted_image_nr_5.nii.gz')]


i=50; j=50; k=80
for filenames in filenames_list:
    data_real = read_nifti_file(filenames[0])
    data_pred = read_nifti_file(filenames[1])
    
    plt.axis('off')
    #plt.imshow(ndimage.rotate(data_real[i,:,:], 90), cmap = 'gray')
    #plt.savefig('real_sagittal_slice_'+str(i), dpi=600)
    
    #plt.imshow(ndimage.rotate(data_real[:,j,:], 90), cmap = 'gray')
    #plt.savefig('real_coronal_slice_'+str(j), dpi=600)
    
    plt.imshow(ndimage.rotate(data_real[:,:,k], 90), cmap = 'gray')
    plt.savefig('real_axial_slice_'+str(k), dpi=600)
        
    #plt.imshow(ndimage.rotate(data_pred[i,:,:], 90), cmap = 'gray')
    #plt.savefig('pred_sagittal_slice_'+str(i), dpi=600)
    
    #plt.imshow(ndimage.rotate(data_pred[:,j,:], 90), cmap = 'gray')
    #plt.savefig('pred_coronal_slice_'+str(j), dpi=600)
    
    plt.imshow(ndimage.rotate(data_pred[:,:,k], 90), cmap = 'gray')
    plt.savefig('pred_axial_slice_'+str(k), dpi=600)
        
    
    i+=30; j+= 44 ; k+=30

